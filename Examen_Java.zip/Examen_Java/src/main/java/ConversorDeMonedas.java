import java.util.Scanner; //Permitiremos la entrada de datos del usuario

public class ConversorDeMonedas { //Definimos como llamaremos la clase principal, en este caso conversordemonedas
    
    public static void main(String[] args) {  try ( //Aqui empezaremos la ejecución
            Scanner scanner = new Scanner(System.in)) {
        int opcion; 
        
        do { //Aqui haremos el menú
            System.out.println("\n--- Conversor de Monedas ---");
            System.out.println("1 Convertir Euros a Dólares");
            System.out.println("2 Convertir Euros a Libras Esterlinas");
            System.out.println("3 Convertir Euros a Yenes");
            System.out.println("4 Salir");
            System.out.print("Selecciona una opción: ");
            opcion = scanner.nextInt();
            
            switch (opcion) {//Aqui pondremos que dependiendo del caso realice una cosa u otra
                case 1 -> {
                    //Aqui haremos el caso 1, de eur a dol
                    System.out.print("Ingresa la cantidad en euros: ");
                    double cantidadEuros = scanner.nextDouble();
                    if (cantidadEuros > 0){
                        double dolares = cantidadEuros * 1.10;
                        System.out.printf("%.2f Euros = %2.f Dólares\n", cantidadEuros, dolares);
                    } else {
                        System.out.println("Ingresa una cantidad válida");
                    }
                }
                    
                case 2 -> {
                    //Aqui haremos el caso 2, de eur a lib
                    System.out.print("Ingresa la cantidad en euros: ");
                    double cantidadEuros = scanner.nextDouble();
                    if (cantidadEuros > 0){
                        double libras =cantidadEuros *0.86;
                        System.out.printf("%.2f Euros = %2.f Libras\n", cantidadEuros, libras);
                    } else {
                        System.out.println("Ingresa una cantidad válida");
                    }
                }
                
                case 3 -> {
                    //Aqui haremos el caso 3, de eur a yen
                    System.out.print("Ingresa la cantidad en euros: ");
                    double cantidadEuros = scanner.nextDouble();
                    if (cantidadEuros > 0){
                        double yenes = cantidadEuros * 150.20;
                        System.out.printf("%.2f Euros = %2.f Yenes\n", cantidadEuros,yenes);
                    } else {
                        System.out.println("Ingresa una cantidad válida");
                    }
                }
                 
                case 4 -> //Haremos el caso 4, que sería salir del programa
                    System.out.println("Saliendo del programa");
                 
                default -> System.out.println("Opción inválida, selecciona la opción válida");
            }
            //Aqui pondremos que dependiendo del caso realice una cosa u otra
                    }while (opcion !=4);
        }
            }
        }
   